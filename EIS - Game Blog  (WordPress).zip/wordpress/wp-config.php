<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'sql0501124');

/** MySQL database username */
define('DB_USER', 'sql0501124');

/** MySQL database password */
define('DB_PASSWORD', 't8ajHIr5');

/** MySQL hostname */
define('DB_HOST', 'lochnagar.abertay.ac.uk');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '9C{=V*`]=4uj,O]Ig/xTai*T;+$CYM|y:Kf-PZUEIM8[>[`%32+b`nG@EW{l>So)');
define('SECURE_AUTH_KEY',  'JQ@-7nDp|<Z6uVO/U%t=u#S,|Sa0AEj+*]1:y8y<l{3s-4]4{b!Ig~}y+t.Fx{t3');
define('LOGGED_IN_KEY',    'mg1[9`khZ/<8]Fu5)q[nj.cmn/VPB!UgmHy-sj*[-`U)M4~,zSOqtq9MaH08PIo1');
define('NONCE_KEY',        ')7#R 1>9)6<+(j;)yB|Ec76!=U!9MuYL;4qqSN9t)^z>PUDtx^?QD4<sEDMgiw0|');
define('AUTH_SALT',        '%ZTX}3*tID$p[By_}>p*V}j97#bhiCXi`^QY0/rYtmLM+O>g>-{*g>.D]Xl7VQcC');
define('SECURE_AUTH_SALT', 'pAbWM7+<h<qM_[~$NE9]DBNBPaAwx+TB)Gl<(=r73z-Nb#~~5z++^}.(Ly2xo#%B');
define('LOGGED_IN_SALT',   'DH3U1WBwA-T8]2vc+/6f[#,{`hz@Xu(qpmhh8?_0e9uZ+*EU~k|-f(ZE:GVy+gHS');
define('NONCE_SALT',       '])o~u(U~3r4ggif-p~-X~Z~Wk]kE+ _~V{R@V(uJj+V,!B1+;=+w(5T,qXR%pfN!');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
 
/* Multisite */
define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', false);
define('DOMAIN_CURRENT_SITE', 'mayar.abertay.ac.uk');
define('PATH_CURRENT_SITE', '/~0501124/wordpress/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);

define('WP_DEBUG', false);

define('PUSH_SYNDICATION_KEY', 'put-your-unqiue-syndication-key-here');

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');


