/** Automatically generated file. DO NOT MODIFY */
package com.ce0941a.logicat2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}