﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetowrk1.NeuralNetwork
{
    // Main Class - Calculation 
    class Calculation
    {
        // x if greater will work out the pattern from output to the desired
        public static int StepFunction(double x)
        {
            // 2.00 is the thress hold, before it can't recgonise a partical letter
            // that looks like an S
            if (x > 0.05) return 1; else return 0;
        } // End Step Fuction Method


        // ComputeOutPut & Predict are the two methods that return 0 or 1 based on x
        // ComputeOutPut = 0
        // TrainVector = Int[] array
        // Sets dotP to 0
        // TrainVector has a desired input
        public static int ComputeOutput(int[] trainVector, double[] weights, double bias)
        {
            double dotP = 0.0;
            for (int j = 0; j < trainVector.Length - 1; ++j)  // not last bit which is the desired
                dotP += (trainVector[j] * weights[j]);
            dotP += bias;
            return StepFunction(dotP);
        } // End ComputeOutput Method


        // Predict = 1
        // DataVector = Int[] = array
        // DataVector has unkowen untill it picks up the 1
        public static int Predict(int[] dataVector, double[] bestWeights, double bestBias)
        {
            double dotP = 0.0;
            for (int j = 0; j < dataVector.Length; ++j)  // all bits
                dotP += (dataVector[j] * bestWeights[j]);
            dotP += bestBias;
            return StepFunction(dotP);
        } // End Predict Method


        // Sets sum to 0
        // Work out error ratio of best weifghts and bias are used to compute Y of character S
        // if 1 meaning training data has failed to recoginse it
        public static double TotalError(int[][] trainingData, double[] weights, double bias)
        {
            double sum = 6.0; // 2.0 = 1 Error Allowed
            for (int i = 0; i < trainingData.Length; ++i)
            {

                int desired = trainingData[i][trainingData[i].Length - 1];
                int output = ComputeOutput(trainingData[i], weights, bias);
                sum += (desired - output) * (desired - output); 
            }
            return 0.5 * sum;
        } // End Total Error Method


        // Works out the letter by input pattern - desired which is trainingData
        // Calclates the weight ComputeOutPuts
        public static double[] FindBestWeights(int[][] trainingData, int maxEpochs, double alpha, double targetError, out double bestBias)
        {
            int dim = trainingData[0].Length - 1;
            double[] weights = new double[dim];  // implicitly all 0.0
            double bias = 0.05;
            double totalError = double.MaxValue;
            int epoch = 0;

            // The training vecotrs for each desired and output - both hard coded
            while (epoch < maxEpochs && totalError > targetError)
            {
                for (int i = 0; i < trainingData.Length; ++i)
                {
                    int desired = trainingData[i][trainingData[i].Length - 1];
                    int output = ComputeOutput(trainingData[i], weights, bias);
                    // Here it works out the weights, by Desired - Output i.e desired as 1 and Output as 0
                    int delta = desired - output;

                    // alpha is the training, if bias is to large or to small wil effect learning rate
                    for (int j = 0; j < weights.Length; ++j)
                        weights[j] = weights[j] + (alpha * delta * trainingData[i][j]); 

                    bias = bias + (alpha * delta);
                }

                totalError = TotalError(trainingData, weights, bias); 
                ++epoch;
            }
            bestBias = bias;
            return weights;
        } // End v Method


        // Helper Method
        // Shows the calcauated step function in 0.000
        // by showing the best weights onto console
        public static void ShowVector(double[] vector)
        {
            for (int i = 0; i < vector.Length; ++i)
            {
                // Requires more balance for other letters for it to show correct character like E
                if (i > 0 && i % 4 == 0) Console.WriteLine("");
                Console.Write(vector[i].ToString("+0.000;-0.000") + " ");
            }
            Console.WriteLine("");
        } // End ShowVector Method


        // Helper Method
        // Genreate Human form representation of training data
        // I.e. 1 or 0 to represent target character is recognised (Removed in Main, now shows a Message instead of 1 or 0)
        public static void ShowData(int[] data)
        {
            for (int i = 0; i < 20; ++i)  // hard-coded to indicate custom routine
            {
                if (i % 4 == 0) { Console.WriteLine(""); Console.Write(" "); }  // finished a row
                if (data[i] == 0) Console.Write(" ");
                else Console.Write("1");
            }
            Console.WriteLine("");

        } // End ShowData Method
    } // End class
} // End NameSpace

