﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetowrk1.NeuralNetwork
{
    //Main Class - PerceptronProgram
    class CharacterRecognition
    {
        // Create a New Instance of Calculation Class
        public void Method1()
        {
            Calculation cal = new Calculation();
        }

        // Allows to Change Console Position
        protected static int origRow;
        protected static int origCol;

        const int SWP_NOSIZE = 0x0001;
        // Set Position of Windows Console Screen
        [DllImport("kernel32.dll", ExactSpelling = true)]
        private static extern IntPtr GetConsoleWindow();

        private static IntPtr MyConsole = GetConsoleWindow();

        [DllImport("user32.dll", EntryPoint = "SetWindowPos")]
        public static extern IntPtr SetWindowPos(IntPtr hWnd, int hWndInsertAfter, int x, int Y, int cx, int cy, int wFlags);



        // Simple Method to Allow Text Above Enter Point in Console
        protected static void WriteAt(string s, int x, int y)
        {
            try
            {
                Console.SetCursorPosition(origCol + x, origRow + y);
                Console.Write(s);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.Clear();
                Console.WriteLine(e.Message);
            }
        }
       
        // Main Entry Point For Application
        static void Main(string[] args)
        {
            try
            {
                // Main Start Point in Console
                Console.WriteLine("\nBegin Perceptron demo\n");

                // Issue Over Array - Must Have Test Against, and allow for training
                int[][] trainingData = new int[2][];
                trainingData[0] = new int[] { 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0 };  // 'A'
                trainingData[1] = new int[] { 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1 };  // 'S'
     
                Console.WriteLine("Goal is to predict patterns that represent 'S'");
                Console.WriteLine("\nTraining input patterns (in row-col descriptive format):\n");

                Calculation.ShowData(trainingData[0]);
                Calculation.ShowData(trainingData[1]);

                origRow = Console.CursorTop;
                origCol = Console.CursorLeft;

                // Input Each Line by row by column i.e. 0,1. 0,2 etc
                WriteAt("     Hello, and Welcome To 0501124 Neural Network ", 0, -1);
                WriteAt("     Constructing Character Recognition ", 0, 2);
                WriteAt("     Console Will Construct The Letter 'S' & Work Out Input As An 'S' ", 0, 3);
                WriteAt("     If Vailed Will Complete, If Not Will Throw Up An Error ", 0, 4);
                WriteAt("    \n     Version 1.0 \n ", 0, 5);

                // Calculate Console Screen to be centre (Easy on The Eye)
                int xpos = 300;
                int ypos = 150;
                SetWindowPos(MyConsole, 0, xpos, ypos, 0, 0, SWP_NOSIZE);

                // Set Console Window Perferences
                Console.WindowWidth = 90;
                Console.WindowHeight = 36;
                Console.WindowTop = 0;
                Console.InputEncoding = Encoding.GetEncoding("windows-1251");
                Console.Title = " +++++ 0501124 Nerual Network: Character Recognition +++++";
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.Green;

                // Calcualtions - Based on Calcualtion Class
                Console.WriteLine("\n\n\n  Finding best weights and bias for a 'S' Please Wait..... ");
                int maxEpochs = 1000;
                double alpha = 0.075;
                double targetError = 0.0; // Change these to allow more errors i.e 5
                double bestBias = 0.0; //
                double[] bestWeights = Calculation.FindBestWeights(trainingData, maxEpochs, alpha, targetError, out bestBias);
                Console.WriteLine("\n  Finished Calculation");

                Console.WriteLine("\n  Calculations Are... \n");
                Calculation.ShowVector(bestWeights);

                // Work Out Character - Change TargetError to test
                double totalError = Calculation.TotalError(trainingData, bestWeights, bestBias);
                Console.WriteLine("\n  After training total error = " + totalError);

                int[] unknown = new int[] { 1, 0, 0, 1, 
                                            1, 0, 0, 1, 
                                            1, 1, 1, 1, 
                                            1, 0, 0, 1, 
                                            1, 0, 0, 1 }; // Enter a Character to test
                Calculation.ShowData(unknown);

                // Works out the Weights and Bias to Identify Character
                int prediction = Calculation.Predict(unknown, bestWeights, bestBias);
                Console.Write("\n Calcualted... ");
                string s0 = " This Character is Not : 'S'";
                string s1 = " Character Has Been Recognised : 'S'";
                if (prediction == 0) Console.WriteLine(s0);
                else Console.WriteLine(s1);

                Console.WriteLine("\n Testing Has Been Completed, Any Key to Exit.... \n");
                Console.ReadLine();
            }



             // Catch Execution Errors
            catch (Exception ex)
            {
                Console.WriteLine("Execution Error!!!");
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            

        } // End Main

    } // End Class

 } // End Namespace



    

