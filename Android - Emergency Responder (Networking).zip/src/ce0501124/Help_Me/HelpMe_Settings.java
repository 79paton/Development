package ce0501124.Help_Me;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

public class HelpMe_Settings extends Activity {
	
	// Variables
	Spinner respondForSpinner;
	CheckBox locationCheckbox;
	EditText responseTextBox;
	PendingIntent intentToFire;

	public static final String autoResponsePref = "autoResponsePref";
	public static final String responseTextPref = "responseTextPref";
	public static final String includeLocPref = "includeLocPref";
	public static final String respondForPref = "respondForPref";
	public static final String defaultResponseText = "defaultResponseText";

	public static final String alarmAction = "ce0501124.Help_Me.AUTO_RESPONSE_EXPIRED";

	@Override
	public void onCreate(Bundle saveInstanceState) {

		super.onCreate(saveInstanceState);
		setContentView(R.layout.helpme_settings);
		// Display items in the activity
		respondForSpinner = (Spinner) findViewById(R.id.spinnerRespondFor);
		locationCheckbox = (CheckBox) findViewById(R.id.checkboxLocation);
		responseTextBox = (EditText) findViewById(R.id.responseText);
		
		// Will use the array in the values folder, to display times
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
				this, R.array.respondForDisplayItems,
				android.R.layout.simple_spinner_item);
		
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		respondForSpinner.setAdapter(adapter);
		
		// Enable button in settings to start a selected timers
		Button okButton = (Button) findViewById(R.id.okButton);
		okButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				// TODO Auto-generated method stub
				savePreferences();
				setResult(RESULT_OK, null);
				finish();
			}

		});
		
		// Disabled button in settings screen, to cancel timer on SMS responder
		Button cancelButton = (Button) findViewById(R.id.cancelButton);
		cancelButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View view) {
				// TODO Auto-generated method stub
				respondForSpinner.setSelection(-1);
				savePreferences();
				setResult(RESULT_CANCELED, null);
				finish();
			}
		});
		// Calls on the updateUIFromPreferences method
		updateUIFromPreferences();

	}
	
	// This method will read the current saved HelpMe_Settings and apply them to the UI
	private void updateUIFromPreferences() {
		// TODO Auto-generated method stub
		String preferenceName = getString(R.string.user_preference);
		SharedPreferences sp = getSharedPreferences(preferenceName, 0);
		
		boolean autoRespond = sp.getBoolean(autoResponsePref, false);
		String respondText = sp
				.getString(responseTextPref, defaultResponseText);
		boolean includeLoc = sp.getBoolean(includeLocPref, false);
		int respondForIndex = sp.getInt(respondForPref, 0);

		// Apply the saved settings to the UI
		if (autoRespond)
			respondForSpinner.setSelection(respondForIndex);
		else
			respondForSpinner.setSelection(0);

		locationCheckbox.setChecked(includeLoc);
		responseTextBox.setText(respondText);

	}
	
	// Method to save current UI settings to shared preference file
	private void savePreferences() {
		// TODO Auto-generated method stub
		// Get The Current Settings from the UI

		boolean autoRespond = respondForSpinner.getSelectedItemPosition() > 0;
		int respondForIndex = respondForSpinner.getSelectedItemPosition();
		boolean includeLoc = locationCheckbox.isChecked();
		String respondText = responseTextBox.getText().toString();

		// Save the to the shared Preference File
		String preferenceName = getString(R.string.user_preference);
		SharedPreferences sp = getSharedPreferences(preferenceName, 0);

		Editor editor = sp.edit();

		editor.putBoolean(autoResponsePref, autoRespond);
		editor.putString(responseTextPref, respondText);
		editor.putBoolean(includeLocPref, includeLoc);
		editor.putInt(respondForPref, respondForIndex);
		editor.commit();

		// Set Alarm to turn off the responder
		setAlarm(respondForIndex);

	}

	// This method will fire an intent when the settings timer expires, which will render it disabled when finished
	// Broadcast receiver will listen for the intent firing and then disables it once done
	private void setAlarm(int respondForIndex) {
		// TODO Auto-generated method stub

		// Create the alarm and register the alarm intent receiver

		AlarmManager alarms = (AlarmManager) getSystemService(ALARM_SERVICE);

		if (intentToFire == null) {
			Intent intent = new Intent(alarmAction);

			intentToFire = PendingIntent.getBroadcast(getApplication(), 0,
					intent, 0);

			IntentFilter filter = new IntentFilter(alarmAction);

			registerReceiver(stopAutoResponderReceiver, filter);

		}

		if (respondForIndex < 1)
			// If "disabled" is selected, cancel the alarm
			alarms.cancel(intentToFire);

		else {
			// Otherwise find the length of time represent
			// by the selection and set the alarm to
			// trigger after that time has passed.
			Resources r = getResources();
			int[] respondForValues = r.getIntArray(R.array.respondForValues);
			int respondFor = respondForValues[respondForIndex];

			long t = System.currentTimeMillis();
			t = t + respondFor * 1000 * 60;

			// Set Alarm
			alarms.set(AlarmManager.RTC_WAKEUP, t, intentToFire);
		}
	}
	
	// Listens for the intent being fired, so it can disable the auto responder the user chose
	private BroadcastReceiver stopAutoResponderReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub

			if (intent.getAction().equals(alarmAction)) {
				String preferenceName = context
						.getString(R.string.user_preference);
				SharedPreferences sp = getSharedPreferences(preferenceName, 0);

				Editor editor = sp.edit();
				editor.putBoolean(autoResponsePref, false);
				editor.commit();
			}
		}
	};
}