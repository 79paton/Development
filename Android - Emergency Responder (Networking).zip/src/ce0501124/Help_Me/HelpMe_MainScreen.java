package ce0501124.Help_Me;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HelpMe_MainScreen extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.helpme_mainscreen);

		// Buttons on Main Screen Linking to designated screen

		// Listener to call SMS responder activity
		((Button) findViewById(R.id.btnSmsRespond))
				.setOnClickListener(new Button.OnClickListener() {
					// Actual press to enter screen
					@Override
					public void onClick(View v) {
						Intent pickLocation = new Intent(
								HelpMe_MainScreen.this, HelpMe_SMSRespond.class);
						startActivity(pickLocation);
					}
				});

		// Listener to call Map activity
		((Button) findViewById(R.id.btnMap))
				.setOnClickListener(new Button.OnClickListener() {
					// Actual press to enter screen
					@Override
					public void onClick(View v) {
						Intent addLocation = new Intent(HelpMe_MainScreen.this,
								HelpMe_Map.class);
						startActivity(addLocation);
					}

				});

		// Listener to call Settings activity
		((Button) findViewById(R.id.btnSettings))
				.setOnClickListener(new Button.OnClickListener() {
					// Actual press to enter screen
					@Override
					public void onClick(View v) {
						Intent deleteLocation = new Intent(
								HelpMe_MainScreen.this, HelpMe_Settings.class);
						startActivity(deleteLocation);
					}
				});

		// Listener to exit responder activity
		((Button) findViewById(R.id.btnExit))
				.setOnClickListener(new Button.OnClickListener() {
					// Actual press to exit application
					@Override
					public void onClick(View v) {
						// finish() is what will close the application
						finish();
					}
				});
	}
}
