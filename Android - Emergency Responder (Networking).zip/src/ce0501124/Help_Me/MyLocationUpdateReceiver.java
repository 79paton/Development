package ce0501124.Help_Me;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.widget.Toast;

public class MyLocationUpdateReceiver extends BroadcastReceiver {

	// Broadcast Receiver that monitors changes in the location movement by the user

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		String key = LocationManager.KEY_LOCATION_CHANGED;
		Location location = (Location) intent.getExtras().get(key);
		
		Toast.makeText(context, "You Have Moved", Toast.LENGTH_SHORT).show();

	}
}
