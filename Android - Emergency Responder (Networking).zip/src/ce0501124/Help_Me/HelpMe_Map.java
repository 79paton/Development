package ce0501124.Help_Me;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class HelpMe_Map extends Activity {

	// Variables 
	LocationListener locationListener;
	
	private GoogleMap map;
	LocationManager location;
	boolean isGPSEnabled = false;
	boolean canGetLocation = false;
	protected LocationManager locationManager;
	
	String provider = LocationManager.GPS_PROVIDER;
	final int locationUpdateRC = 0;  
	int flags = PendingIntent.FLAG_UPDATE_CURRENT;
	PendingIntent pendingIntent;
	
	int t = 5000; //Milliseconds
	int distance = 5; //Meters
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.helpme_map);

		// Displays the map view
		map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map))
				.getMap();
		
		// Typical road map setting shows features such as river etc on map
		// Basic Maps
		map.setMapType(GoogleMap.MAP_TYPE_NORMAL);

		// system service to access the location based services
		// This service will require the permission ACCESS_FINE_LOCATION &
		// ACCESS_COARSE_LOCATION
		// Fine is a high accuracy to find the users location better
		LocationManager locationManager;
		String svcName = Context.LOCATION_SERVICE;
		locationManager = (LocationManager) getSystemService(svcName);

		// This is the criteria class used to help find the best location provider
		Criteria criteria = new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_FINE);
		criteria.setPowerRequirement(Criteria.POWER_LOW);
		criteria.setAltitudeRequired(false);
		criteria.setBearingRequired(false);
		criteria.setSpeedRequired(false);
		criteria.setCostAllowed(true);
		
		// This will set the criteria class to find the best provider on
		// the requirements above
		String provider = locationManager.getBestProvider(criteria, true);
		// Finds the users last known location
		Location location = locationManager.getLastKnownLocation(provider);
		// Calls the registerLocationUpdates method
		registerLocationUpdates(locationManager);
		// Calls the GetLocation method
		GetLocation(location);
		// Passes in a new location listener object - 2000 is for 2 seconds
		// 10 is in meters the user must move for the listener to fire
		locationManager
				.requestLocationUpdates(provider, 2000, 10, locationListener);
		
		map.setMyLocationEnabled(true);
		
		}

	private void GetLocation(Location location) {
		
		try {
			// Text view to show getLongitude and getLatitude
			// Both in forward geocoding showing the numbers
			// and reverse geocoding showing the actual text of the address
			TextView Location;
			Location = (TextView) findViewById(R.id.Location);
			// Variable to use for the forward gecoding
			String latLongString = "No Location Found";
			// Variable to use for the reverse gecoding
			String addressString = "No Address Found";
			
			if (!isGPSEnabled) {
				if (location != null) {
					// lat & lng variables for displaying location in numbers
					double lat = location.getLatitude();
					double lng = location.getLongitude();
					// Displays to screen
					latLongString = "Lat:" + lat + "\nLong:" + lng;
					
					// Variables used for reverse gecoding
					double latitude = location.getLatitude();
					double longitude = location.getLongitude();
					// Used to pull the location for location manager
					Geocoder gc = new Geocoder(this, Locale.getDefault());
					// Check to see if gps is available
					if (!Geocoder.isPresent())
						// if not available
						addressString = "No geocoder available";
					else {
						try {
							List<android.location.Address> addresses = gc
									.getFromLocation(latitude, longitude, 1500);
							StringBuilder sb = new StringBuilder();
							if (addresses.size() > 0) {
								android.location.Address address = addresses
										.get(0);

								for (int i = 0; i < address
										.getMaxAddressLineIndex(); i++)
									sb.append(address.getAddressLine(i))
											.append("\n");

								sb.append(address.getLocality()).append("\n");
								sb.append(address.getPostalCode()).append("\n");
								sb.append(address.getCountryName());
							}
							addressString = sb.toString();
						} catch (IOException e) {
							Log.d("WHEREAMI", "IO Exception", e);
						}
					}
					Location.setText("Your Current Position is:\n\n" + latLongString + "\n" + "\n" 
							+ "Your Address:\n\n" + addressString);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	

	 private void registerLocationUpdates(LocationManager myLocationListener) {
		 
		 String provider = LocationManager.GPS_PROVIDER;

		 int t = 5000;     // milliseconds
		 int distance = 5; // meters
		 // This is used for location Listener, instead of an intent
		 final LocationListener locationListener = new LocationListener() {
		 
		public void onLocationChanged(Location location) {
			Toast.makeText(getApplicationContext(),
					location.getLatitude() + " " + location.getLongitude(),
					Toast.LENGTH_LONG).show();

			map.addMarker(new MarkerOptions()
					.position(
							new LatLng(location.getLatitude(), location
									.getLongitude()))
					.title("my position")
					.icon(BitmapDescriptorFactory
							.fromResource(R.drawable.ic_launcher)));
			// This Allows for camera zoom once it loads the map view
			// 1.0f is the highest and 21.0f is the lowest
			map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(
					location.getLatitude(), location.getLongitude()), 16.0f));
		}

		public void onProviderDisabled(String provider) {

		}

		public void onProviderEnabled(String provider) {
		}

		public void onStatusChanged(String Provider, int status, Bundle extras) {
		}

	};
	// provider will use location manager gps provider
	// t will use distance variable
	// Distance will use the distance variable
	myLocationListener.requestLocationUpdates(provider, t, distance,
              locationListener);


	this.locationListener = locationListener;

	}

}


