/*package ce0501124.Help_Me;

import java.util.ArrayList;

import java.util.concurrent.locks.ReentrantLock;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;

public class ReceivedBroadCastReceiver extends BroadcastReceiver {

	// Ensures thread-safe handling of the Array List
	ReentrantLock lock;
	// Reference to the check box in XML
	CheckBox locationCheckBox;
	// Will bind the Array List to the List View using an Array
	ArrayList<String> requesters;
	ArrayAdapter<String> aa;

	public String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
	

	// TODO Auto-generated method stub
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stud
		
		
		if (intent.getAction().equals(SMS_RECEIVED)) {
			String queryString = context.getString(R.string.querystring).toLowerCase();

			Bundle bundle = intent.getExtras();
			if (bundle != null) {
				Object[] pdus = (Object[]) bundle.get("pdus");
				SmsMessage[] messages = new SmsMessage[pdus.length];
				for (int i = 0; i < pdus.length; i++)
					messages[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
				for (SmsMessage message : messages) {
					if (message.getMessageBody().toLowerCase()
							.contains(queryString))
						requestReceived(message.getOriginatingAddress());
			
				}
			}
		}
	}

	private void requestReceived(String from) {
		// TODO Auto-generated method stub
		if (!requesters.contains(from)) {
			lock.lock();
			requesters.add(from);
			aa.notifyDataSetChanged();
			lock.unlock();

		}
	}

	
}*/
