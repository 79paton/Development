package ce0501124.Help_Me;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.locks.ReentrantLock;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

public class HelpMe_SMSRespond extends Activity {
	
	public static final String SENT_SMS = "ce0501124.Help_Me.SMS_SENT";
	public static final String SMS_RECEIVED =
		      "android.provider.Telephony.SMS_RECEIVED";
	

	// Ensures thread-safe handling of the Array List
	ReentrantLock lock;
	// Reference to the check box in XML
	CheckBox locationCheckBox;
	// Will bind the Array List to the List View using an Array
	ArrayList<String> requesters;
	ArrayAdapter<String> aa;
	Activity context;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.helpme_smsrespond);
		
		lock = new ReentrantLock();
		requesters = new ArrayList<String>();
		// Calls back the wire up controls method
		wireUpControls();
	
	}

	// Will store the new numbers that match the responses from the strings
	// It will display the numbers in a list view in an array, by storing new numbers at the start
	// Will also allow a check box to be selected, to send current location
	private void wireUpControls() {
		// TODO Auto-generated method stub
		locationCheckBox = (CheckBox) findViewById(R.id.checkboxSendLocation);
		ListView myListView = (ListView) findViewById(R.id.myListView);

		int layoutID = android.R.layout.simple_list_item_1;
		aa = new ArrayAdapter<String>(this, layoutID, requesters);
		myListView.setAdapter(aa);

		// Check box button to send current location
		Button okButton = (Button) findViewById(R.id.okButton);
		okButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {
				respond(true, locationCheckBox.isChecked());
			}
		});
		
		// unchecked box, not to send location with auto response
		Button notOkButton = (Button) findViewById(R.id.notOkButton);
		notOkButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {
				respond(false, locationCheckBox.isChecked());
			}
		});
		// Button to start settings screen, by calling the start auto responder method
		Button autoResponderButton = (Button) findViewById(R.id.autoResponder);
		autoResponderButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {
				startAutoResponder();
			}

		});
		
		// Exits back to main screen
		((Button) findViewById(R.id.btnExit))
		.setOnClickListener(new Button.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent Exit = new Intent(
						HelpMe_SMSRespond.this, HelpMe_MainScreen.class);
				startActivity(Exit);

			}

		});
	}

	
	//  Method that will process if user checks send location box in SMS respond activity
	// this will remove each number from the list and send the required message back	
	public void respond(boolean ok, boolean includeLocation) {
		// TODO Auto-generated method stub
		// Calls the all clear text string in the array, to send back the string message
		String okString = getString(R.string.allClearText);
		// Calls the all clear text string in the array, to send back the string message
		String notOkString = getString(R.string.maydayText);
		
		String outString = ok ? okString : notOkString;
		
		@SuppressWarnings("unchecked")
		ArrayList<String> requestersCopy = (ArrayList<String>)requesters.clone();
		
			for (String to : requestersCopy)
				respond(to, outString, includeLocation);		
	}
	
	// Users can also select the check box for sending along with the message
	// their location details in a second message
	// This will use the SmsManager to pend, once the first message has been sent
	private void respond(String to, String response, boolean includeLocation) {
		// TODO Auto-generated method stub
	
		lock.lock();
		requesters.remove(to);
		aa.notifyDataSetChanged();
		lock.unlock();
		
		SmsManager sms = SmsManager.getDefault();
		
		Intent intent = new Intent(SENT_SMS);
		intent.putExtra("recipient", to);
		
		PendingIntent sendPI = 
				PendingIntent.getBroadcast(getApplicationContext(), 0, intent, 0);
		
		//  Send the message
		sms.sendTextMessage(to, null, response, sendPI, null);
		
		StringBuilder sb = new StringBuilder();
		
		// Code to pick up your current location
		if(includeLocation) {
			String ls = Context.LOCATION_SERVICE;
			LocationManager lm = (LocationManager)getSystemService(ls);
			Location l =
					lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
			
			if (l == null)
				sb.append("Location Unknown");
			else {
				sb.append("I'm @:\n");
				sb.append(l.toString() + "\n");
				
				List<Address> address;
				Geocoder g = new Geocoder(getApplicationContext(),
						Locale.getDefault());
				
				try {
					address = g.getFromLocation(l.getLatitude(), l.getLongitude(), 1);
					
					if(address != null) {
						Address currentAddress = address.get(0);
						if(currentAddress.getMaxAddressLineIndex() > 0) {
							for (int i = 0; i < currentAddress.getMaxAddressLineIndex();
									i++) {
								sb.append(currentAddress.getAddressLine(i));
								sb.append("\n");
							}
						}
						else {
							if (currentAddress.getPostalCode()!= null)
								sb.append(currentAddress.getPostalCode());
						}
					}	
				}catch (IOException e) {
					Log.e("SMS_REPONDER", "IO Exception.", e);
				}
				ArrayList<String> locationMsgs = sms.divideMessage(sb.toString());
				for (String locationMsg : locationMsgs)
						sms.sendTextMessage(to, null, locationMsg, null, null);
			}
		}
	}
	// Calls this activity once the user pick a respond time in the settings screen
	private void startAutoResponder() {
		// TODO Auto-generated method stub
		startActivityForResult(new Intent(HelpMe_SMSRespond.this, HelpMe_Settings.class), 0);
	}
	
	// Broadcast receiver to listen for incoming messages
	// It will only store numbers in the array that matches the query string in the array
	// by calling on the request received method
	
	BroadcastReceiver emergencyResponseRequestReceiver =   new BroadcastReceiver() { 
	
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		try {
		if (intent.getAction().equals(SMS_RECEIVED)) {
			String queryString = getString(R.string.querystring).toLowerCase();

			Bundle bundle = intent.getExtras();
			if (bundle != null) {
				Object[] pdus = (Object[]) bundle.get("pdus");
				SmsMessage[] messages = new SmsMessage[pdus.length];
				for (int i = 0; i < pdus.length; i++)
					messages[i] = SmsMessage
							.createFromPdu((byte[]) pdus[i]);
				for (SmsMessage message : messages) {
					if (message.getMessageBody().toLowerCase()
							.contains(queryString))
						requestReceived(message.getOriginatingAddress());
					}
				}
			}
		} catch(Exception e) {
		Toast.makeText(HelpMe_SMSRespond.this, "Error", Toast.LENGTH_SHORT).show();
		}
	}
	};
	
	// Add the originating number that has requested if user is OK
	// Pulls in the incoming number to the array list
	
	private void requestReceived(String from) {
		// TODO Auto-generated method stub
		if (!requesters.contains(from)) {
			lock.lock();
			requesters.add(from);
			aa.notifyDataSetChanged();
			lock.unlock();
			
			// Check for auto-responder
			String preferenceName = getString(R.string.user_preference);
			SharedPreferences prefs
				= getSharedPreferences(preferenceName, 0);
			
			boolean autoRespond = prefs.getBoolean(HelpMe_Settings.autoResponsePref,  false);
			
			if (autoRespond) {
				String respondText = prefs.getString(HelpMe_Settings.responseTextPref,
														HelpMe_Settings.defaultResponseText);
				boolean includeLoc = prefs.getBoolean(HelpMe_Settings.includeLocPref,  false);
				
				respond(from, respondText, includeLoc);
			}
			
		}
	}
	
	private BroadcastReceiver attemptedDeliveryReceiver = new
			BroadcastReceiver() {
		@Override
		public void onReceive(Context _context, Intent _intent) {
			if(_intent.getAction().equals(SENT_SMS)) {
				if(getResultCode() != Activity.RESULT_OK) {
					String recipient = _intent.getStringExtra("recipient");
					requestReceived(recipient);
				}
			}
		}
	
	};

	@Override
	public void onResume() {
		super.onResume();
		IntentFilter filter = new IntentFilter(SMS_RECEIVED);
		registerReceiver(emergencyResponseRequestReceiver, filter);
		
		IntentFilter attemptedDeliveryFilter = new IntentFilter(SENT_SMS);
		registerReceiver(attemptedDeliveryReceiver,
				attemptedDeliveryFilter);
	}

	@Override
	public void onPause() {
		super.onPause();
		
		unregisterReceiver(emergencyResponseRequestReceiver);
		
		unregisterReceiver(attemptedDeliveryReceiver);

	}
}
