package ce0501124.Help_Me;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Toast;

public class HelpMe_PhoneState extends Activity {
	
	//Variables
	TelephonyManager telephonyManager;
    PhoneStateListener listener;
	
    @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//Calls on the system service telephony service
		telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		
		// Telephony Manager will call the state of device
		PhoneStateListener callStateListener = new PhoneStateListener() {
		public void onCallStateChanged(int state, String incomingNumber){
			String callStateStr = "unknow";
			// Phone is not ringing
			switch (state){
			case TelephonyManager.CALL_STATE_IDLE:
				callStateStr = "idle";
			break;
			// When phone is ringing
			case TelephonyManager.CALL_STATE_OFFHOOK:
				callStateStr = "off Hock";
			break;
			// When phone is in a call
			// Also displays the incoming number at the beginning
			case TelephonyManager.CALL_STATE_RINGING:
				callStateStr = "RINGING. Incoming number is: "+ incomingNumber;
			break;
			default : break;
			}
			Toast.makeText(HelpMe_PhoneState.this, callStateStr, Toast.LENGTH_LONG).show();
		}
	};
	// Listens for the call state
	telephonyManager.listen(callStateListener, 
			PhoneStateListener.LISTEN_CALL_STATE);
	}
}

