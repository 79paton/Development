package ce0501124.Help_Me;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.telephony.SmsManager;
import android.widget.Toast;

public  class OutGoingSMS extends Activity{
	
	
	public void sendSMS(String sendTo, String myMessage, Context context) {
	String SEND_SMS_ACTION = "SEND_SMS_ACTION";
	String DELIVERED_SMS_ACTION = "DELIVERED_SMS_ACTION";
	
	// send intent parameter
	Intent sendIntent = new Intent(SEND_SMS_ACTION);
	PendingIntent sendPI = PendingIntent.getBroadcast(context.getApplicationContext(), 0, sendIntent, PendingIntent.FLAG_UPDATE_CURRENT);
	
	//delivery intent parameter
	Intent deliveryIntent = new Intent(DELIVERED_SMS_ACTION);
	PendingIntent deliverPI = PendingIntent.getBroadcast(context.getApplicationContext(), 0, deliveryIntent, PendingIntent.FLAG_UPDATE_CURRENT);
	
	// Broadcast receiver to check for sms status 
	registerReceiver(new BroadcastReceiver() {
	@Override
	public void onReceive(Context _context, Intent _intent) {
		// TODO Auto-generated method stub
		String resultText = "UNKNOWN";
		
		switch(getResultCode()) {
		case Activity.RESULT_OK:
			resultText = "Successful"; break;
		case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
			resultText = "Failed"; break;
		case SmsManager.RESULT_ERROR_RADIO_OFF:
			resultText = "Radio Off"; break;
		case SmsManager.RESULT_ERROR_NULL_PDU:
			resultText = "NO PDU specified"; break;
		case SmsManager.RESULT_ERROR_NO_SERVICE:
			resultText = "Transmission  Failed: No Service"; break;
			}
		Toast.makeText(_context, resultText, Toast.LENGTH_LONG).show();
		}
	},
	new IntentFilter(SEND_SMS_ACTION));

	
	registerReceiver(new BroadcastReceiver() {
		@Override
		public void onReceive(Context _context, Intent _intent)
		{
			Toast.makeText(_context, "SMS DELIVERED", Toast.LENGTH_LONG).show();
		}
	},
	new IntentFilter(DELIVERED_SMS_ACTION));
	
	SmsManager sms = SmsManager.getDefault();
	sms.sendTextMessage(sendTo, null, myMessage, sendPI, deliverPI);
	
}


}