package ce0501124.Help_Me;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.widget.Toast;

public class HelpMe_IncomingNumber extends BroadcastReceiver {
	
	// Broadcast Receiver that will extract the current phone state
	// and incoming phone number as a toast
	// Registered in the manifest as a receiver, with the action Phone State
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		String phoneState = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
			if (phoneState.equals(TelephonyManager.EXTRA_STATE_RINGING)){
				String phoneNumber = 
							intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
					Toast.makeText(context,
							"Incoming Call From:" + phoneNumber, Toast.LENGTH_LONG).show();
					
				}
			}
	}
