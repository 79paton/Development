<!DOCTYPE html>

<!-- Display the database data to the mobile app link Temperature Page
	- allows user to see the history of the temperatures 
-->

<html>
<head>
	<title> Electric Imp Temperature Ratings </title>
	
	<!-- CSS to run for mobile app page -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://code.jquery.com/mobile/1.2.0/jquery.mobile-1.2.0.min.css">
    <script src="http://code.jquery.com/jquery-1.8.2.min.js"></script>
    <script src="http://code.jquery.com/mobile/1.2.0/jquery.mobile-1.2.0.min.js"></script>
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	
	<!--- Refresh every 10s --->
	<script>
		setTimeout(function(){location = ''}, 10000)
	</script>
	
</head>
<!-- Run the page after three seconds-->
<body onload="setInterval(location.reload(forceGet),3000);" >


    <div data-role="page" id="pageone">
 
        <div data-role="header">
            <h1> Temperature </h1>
        </div> <!-- /header -->
 
        <div data-role="content" data-Swatch="b">
		
            <p align="center"> Display On And Off Board Readings
			</p>
			<div align="center">
				<table data-role="table" data-mode="columntoggle" id="temp-table">
				<!--  Display headings for each data returing -->
					<thead>
						<tr>
						    <th>Setting</th>
						    <th width="100px">Time</th>
						    <th>Reading</th>
						</tr>
					</thead>
					<!-- Pulls the data from the gettemp.php here, include 
					     runs all the code from gettemp.php-->
					<tbody>
						<?php include "gettemp.php"; ?>
					</tbody>
				</table>
			</div>
        </div><!-- /content -->
 
        <div data-role="footer" data-position="fixed">
            <h4> ID Neil Paton 0501124 </h4>
        </div><!-- /footer -->
 
    </div><!-- /page one-->
    
    
    
</body>
</html>