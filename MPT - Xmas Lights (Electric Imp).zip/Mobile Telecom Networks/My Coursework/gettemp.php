<?php

// Retrieve the temperatures from the database and display on displaytemp.php
// will also have a link on mobile app to view current temperatures

echo ("<center><br><h2> TEMPERATURE READINGS </h2>");

// Database Variables
$username="sql0501124";
$password="t8ajHIr5";
$database="lochnagar.abertay.ac.uk";

// Connection to Database
$con = mysql_connect("lochnagar.abertay.ac.uk","sql0501124","t8ajHIr5");
@mysql_select_db($username) or die ("UNABLE");

// create query to pull all from MyTemp Table
$query = "SELECT * FROM MyTemp
			ORDER BY time DESC
			LIMIT 10";
			
// Run Query result query
$result = mysqli_query($con, $query) or die ("Error in query: $query. " . mysqli_error());

// Query sql1 query	
$sql = "SELECT temp FROM MyTemp WHERE temp > 30";
// Run sql1 query
$result2=mysql_query($sql) or die ("Unable to run query 1");
			



// condition to check if result is true
if (mysqli_num_rows($result) > 0) {
    // then display results
	while ($row = mysqli_fetch_array($result)){
	
		echo("<tr><td align='center' width='100px'>".$row['location']. "</td>");
		$time = date('H:i:s', strtotime($row['time']));
		echo("<td align='center'> ".$time." </td>");
		echo("<td align='center'>".$row['temp']."</td></tr>");
	}
}

// if result2 query is true run header
if($result2 = TRUE){
	$raiseAlarm;
	$msg = "Fire";
  // Run the SMS Send Script to Alert of Fire
  //header('Location: smssend.php');
  // header to run another script with in one second
  //header('Refresh: 1; URL=http://mayar.abertay.ac.uk/~0501124/Temp/smssend.php'); */
	
}

// Test To Check if Query Works - Works Fine
/*echo '<table width="50%" border="0" cellspacing="0" cellpadding="0">';
	
	while ($db_field = mysql_fetch_assoc($result)) {
	echo '<tr>
			<td>' .$db_field['temp'].  '</td>
			</tr>';
		}
		echo '</table>';*/
		
if($raiseAlarm){

	$URL = "http://driesh.abertay.ac.uk/~g510572/sms/sendsms.cfm";
	$PHONE = "07712102956";
	$SMSTEXT = $msg;
	$USERNAME = "0501124";

	$_POST['mphone'] = $PHONE;
	$_POST['smstext'] = $SMSTEXT;
	$_POST['username'] = $USERNAME;

	$encoded = '';
	// include GET as well as POST variables; your needs may vary.
	foreach($_POST as $name => $value) {
	 $encoded .= urlencode($name).'='.urlencode($value).'&';
	}
	// chop off last ampersand
	$encoded = substr($encoded, 0, strlen($encoded)-1);

//----------------------------------------------------------------

	// create a new cURL handle resource
	$ch = curl_init();
	// set URL and other appropriate options
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS,  $encoded);
	curl_setopt($ch, CURLOPT_URL, $URL);
	curl_setopt($ch, CURLOPT_HEADER, true);
	// grab URL and pass it to the browser
	curl_exec($ch);
	// close cURL resource, and free up system resources
	curl_close($ch);

}​
		
// close connection		
mysqli_close($con);
?>