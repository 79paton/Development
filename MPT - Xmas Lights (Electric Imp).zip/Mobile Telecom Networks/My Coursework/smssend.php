<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<!--	smssend.php to run in con junction with gettemp.php
		fires of SMS to mobile number placed in input boxes below
		on smssend.php script - was going to extend this by putting login
		and style for user to access and update their details

		smssend.php script will run automatically when gettemp.php meets a condition
<!--	this being once the temperature is beyond a certain point -->

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> ALERT FIRE </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<!-- Once the condition is met in gettemp.php run smssend.php within five seconds --->
<SCRIPT LANGUAGE="JavaScript"><!--
setTimeout('document.test.submit()',5000);
//--></SCRIPT>

</head>

<body>

<!-- Input form to place details and message to send through script bloew in CFM --->

<form id="test" name="test" method="post" action="http://driesh.abertay.ac.uk/~g510572/sms/sendsms.cfm">
<label>mphone -
<input type="formfield" name ="mphone" value="07712102956" id="mphone" />
</label>
<p>

<label>smstext -
<input type="formfield" name="smstext" value="ALERT CONTROL BOX ON FIRE" id="smstext" />
</label>
</p>

<label>username -
<input type="formfield" name="username" value="0501124" id="username" />
</label>
</p>

<!-- Button to Submit -->
<p>
	<input type="submit" name="SMS" id="button" value="Submit" />
&nbsp; </p>
</form>

</body>
</html>