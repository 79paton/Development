<?php

// Simple retreive the tempertures for onboard and external on the electric imp
// send the data from agaent code to here and push them to the MyTemp database table

// Global Variables that pulls the data from electric imp
// through pulling it with file_get_contents and then decoding it 
// through jason_decode
// then set up the current state to be inserted through
// temp and location global variables

$contents = file_get_contents("php://input");
$state = json_decode($contents);
$temp = $state->temp;
$location = $state->location;


// Run database connection
$con = mysql_connect("lochnagar.abertay.ac.uk","sql0501124","t8ajHIr5");

// Check if connection is ok, i not show error message
if (!$con)
  {
	die('Could not connect: ' . mysql_error());
  }
	
	// open database connection
	mysql_select_db("sql0501124", $con);

	// run query to insert data
	mysql_query("INSERT INTO MyTemp (location, temp)
	VALUES ('$location', '$temp')");

// close connection
mysql_close($con);
?>