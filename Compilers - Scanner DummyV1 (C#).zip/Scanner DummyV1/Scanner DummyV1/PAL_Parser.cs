﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// Ardkit - Reference
using AllanMilne.Ardkit;

namespace PAL_Language
{
    // Main Classs PALParser inherits Recovering Rd Parser (Ardkit)
    public class PAL_Parser : RecoveringRdParser
    {
        // Variables
        private PAL_Semantics semantics;
        private List<IToken> tlist;

        // Constructor
        public PAL_Parser()
            : base(new PAL_Scanner())
        {
            semantics = new PAL_Semantics(this);
        } // Eend Constructor


        // Recogniser Method for BNF Statement <Program>
        // <Program> ::= PROGRAM Identifier WITH <VarDecls> IN (<Statement>) + END ;
        protected override void recStarter()
        {
            Scope.OpenScope();
            mustBe("PROGRAM");
            semantics.CurrentType = LanguageType.String;
            semantics.DeclareId(scanner.CurrentToken);
            mustBe(Token.IdentifierToken);
            semantics.ResetCurrentType();
            mustBe("WITH");
            recVarDecls();
            mustBe("IN");
            do
            {
                recStatement();
            } while (have(Token.IdentifierToken) || have("UNTIL") ||
                have("IF") || have("INPUT") || have("OUTPUT"));
            mustBe("END");
            Scope.CloseScope();

        } // End recStarter Method


        // Recogniser Method for BNF Statement <VarDecles>
        // <VarDecls> ::= (<IdentList> AS <Type>)* ;
        private void recVarDecls()
        {
            semantics.ResetCurrentType();
            while (have(Token.IdentifierToken))
            {
                recIdentList();
                mustBe("AS");
                recType();
            }
        } // End recVarDecls Method


        // Recogniser Method for BNF Statement <Type>
        // <Type> ::= REAL | INTEGER ;
        private void recType()
        {
            

                if (have("REAL"))
                {
                    semantics.CurrentType = LanguageType.Real;
                    mustBe("REAL");   
                }
                else
                {
                if (have("INTEGER"))
                    semantics.CurrentType = LanguageType.Integer;
                    mustBe("INTEGER"); 
                }

                foreach (IToken t in tlist)
                {
                    Console.WriteLine();
                    semantics.DeclareId(t);
                }

        } // End recType Method


        // Recogniser Method for BNF Statement <Statement>
        // <Statement> ::= <Assignment> | <Loop> | <Conditional> | <I-o> ;
        private void recStatement()
        {
            if (have(Token.IdentifierToken))
                recAssignment();
            else if (have("UNTIL"))
                recLoop();
            else if (have("IF"))
                recConditional();
            else if (have("INPUT") || have("OUTPUT"))
                recIo();
           //else syntaxError("<Statement>");

        } // End recStatement Method


        // Recogniser Method for BNF Statement <Assgnment>
        // <Assignment> ::= Identifier = <Expression> ;
        private void recAssignment()
        {
            semantics.CurrentType = LanguageType.Undefined;
            semantics.CheckId(scanner.CurrentToken);
            mustBe(Token.IdentifierToken);
            mustBe("=");
            recExpression();
        } // End RecAssigment Method


        // Recogniser Method for BNF Statement <Loop>
        // <Loop> ::= UNTIL <BooleanExpr> REPEAT (<Statement>)* ENDLOOP ;
        private void recLoop()
        {
            mustBe("UNTIL");
            recBooleanExpr();
            mustBe("REPEAT");
            while (have(Token.IdentifierToken) || have("UNTIL") ||
                have("IF") || have("INPUT") || have("OUTPUT"))
            {
                recStatement();
            }
            mustBe("ENDLOOP");

        } // End recLoop Method


        // Recogniser Method for BNF Statement <Conditional>
        // <Conditional> ::= IF <BooleanExpr> THEN (<Statement>)* ( ELSE (<Statement>)* )? ENDIF ;
        private void recConditional()
        {
            mustBe("IF");
            recBooleanExpr();
            mustBe("THEN");
            while (have(Token.IdentifierToken) || have("UNTIL") ||
                have("IF") || have("INPUT") || have("OUTPUT"))
            {
                recStatement();
            }
            if (have("ELSE"))
            {
                mustBe("ELSE");
                while (have(Token.IdentifierToken) || have("UNTIL") ||
                    have("IF") || have("INPUT") || have("OUTPUT"))
                {
                    recStatement();
                } 
            }
            mustBe("ENDIF");

        } // End recConditional Method

        // Recogniser Method for BNF Statement <Io>
        // <I-o> ::= INPUT <IdentList> | OUTPUT <Expression> ( , <Expression>)* ;
        private void recIo()
        {
            if (have("INPUT") || have("OUTPUT"))
            {
                if (have("INPUT"))
                {
                    mustBe("INPUT");
                    recIdentList();
                }
                else
                {
                    mustBe("OUTPUT");
                    recExpression();
                    while (have(","))
                    {
                        mustBe(",");
                        recExpression();
                    }
                }
            }
        } // End recIo Method


        // Recogniser Method for BNF Statement <Expression>
        // <Expression> ::= <Term> ( (+|-) <Term>)* ;
        private void recExpression()
        {
            
            recTerm();
            while (have("+") || have("-"))
            {
                if (have("+"))
                    mustBe("+");
                else
                    mustBe("-");
                {
                    recTerm();
                }
            }
        } // End recExpression Method


        // Recogniser Method for BNF Statement <Term>
        // <Term> ::= <Factor> ( (*|/) <Factor>)* ;
        private void recTerm()
        {
            recFactor();
            while (have("*") || have("/"))
            {
                if (have("*"))
                    mustBe("*");
                else
                    mustBe("/");
                {
                    recFactor();
                }
            }
        } // End recTerm Method


        // Recogniser Method for BNF Statement <Factor>
        // <Factor> ::= (+|-)? ( <Value> | "(" <Expression> ")" ) ;
        private void recFactor()
        {
            if (have("+") || have("-"))
            {
                if (have("+"))
                    mustBe("+");
                else
                    mustBe("-");
            }

            if (have(Token.IdentifierToken) || have(Token.IntegerToken) || have(Token.RealToken))
            {
                recValue();
            }
            else if (have("("))
            {
                
                    mustBe("(");
                    recExpression();
                    mustBe(")");
            }
            else
            {
                syntaxError("<Factor>");
            }

        } // End recFactor Method


        // Recogniser Method for BNF Statement <Value>
        // <Value> ::= Identifier | IntegerValue | RealValue ;
        private void recValue()
        {
            if (have(Token.IdentifierToken))
            {
                semantics.CheckId(scanner.CurrentToken);
                mustBe(Token.IdentifierToken);
            }
            else if (have(Token.IntegerToken))
            {
                semantics.CheckType(scanner.CurrentToken);
                mustBe(Token.IntegerToken);
            }

            else if (have(Token.RealToken))
            {
                semantics.CheckType(scanner.CurrentToken);
                mustBe(Token.RealToken);
            }
            else
            {
                syntaxError("<Value>");
            }

        } // End recValue Method


        // Recogniser Method for BNF Statement <BooleanExpr>
        // <BooleanExpr> ::= <Expression> ("<" | "=" | ">") <Expression> ;
        private void recBooleanExpr()
        {
            recExpression();
            {
                if (have("<")) 
                    mustBe("<");
                else if (have("=")) 
                    mustBe("=");
                else if (have(">")) 
                    mustBe(">");
                else syntaxError("<BooleanExpr");
            }
            recExpression();
        } // End recBooleanExpr Method


        // Recogniser Method for BNF Statement <Identlist>
        // <IdentList> ::= Identifier ( , Identifier)* ;
        private void recIdentList()
        {

            tlist = new List<IToken>();
            if (have(Token.IdentifierToken))
            {
                tlist.Add(scanner.CurrentToken);
                mustBe(Token.IdentifierToken);
            }
            while (have(","))
            {
                mustBe(",");
                if (have(Token.IdentifierToken))
                {
                    tlist.Add(scanner.CurrentToken);
                    mustBe(Token.IdentifierToken);
                }
            }


        } // End recIdentlist Method

    } // End MyParser class.
}// End my Name Space
