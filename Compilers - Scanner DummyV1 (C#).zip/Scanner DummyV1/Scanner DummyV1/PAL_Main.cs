﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AllanMilne.Ardkit;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;

namespace PAL_Language
{
    class PAL_Main
    {
        // Variables
        protected static int origRow;
        protected static int origCol;
        const int SWP_NOSIZE = 0x0001;
        // Set Position of Windows Console Screen
        [DllImport("kernel32.dll", ExactSpelling = true)]
        private static extern IntPtr GetConsoleWindow();

        private static IntPtr MyConsole = GetConsoleWindow();

        [DllImport("user32.dll", EntryPoint = "SetWindowPos")]
        public static extern IntPtr SetWindowPos(IntPtr hWnd, int hWndInsertAfter, int x, int Y, int cx, int cy, int wFlags);

        // Simple Method to Allow Text Above Enter Point in Console
        protected static void WriteAt(string s, int x, int y)
        {
            try
            {
                Console.SetCursorPosition(origCol + x, origRow + y);
                Console.Write(s);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.Clear();
                Console.WriteLine(e.Message);
            }
        }

        static void Main(string[] args)
        {         
            StreamReader infile = null;

            // Set Position for Text
            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;

            // Input Each Line by row by column i.e. 0,1. 0,2 etc
            WriteAt("     Hello, and Welcome To 0501124 Compiler Build ", 0, 1);
            WriteAt("     Constructing A Compiler For The Langauge PAL ", 0, 2);
            WriteAt("     Console Will Prompt You For A Path To Run The PAL Language You Wish ", 0, 3);
            WriteAt("     If valid Will Complete, If Not Will Throw Up An Error List To Check ", 0, 4);
            WriteAt("    \n     Version 1.0 8) \n ", 0, 5);

            // Calculate Console Screen to be centre (Easy on The Eye)
            int xpos = 300;
            int ypos = 150;
            SetWindowPos(MyConsole, 0, xpos, ypos, 0, 0, SWP_NOSIZE);

            // Set Console Window Perferences
            Console.WindowWidth = 90;
            Console.WindowHeight = 36;
            Console.WindowTop = 0;
            Console.InputEncoding = Encoding.GetEncoding("windows-1251");
            Console.Title = " +++++ 0501124 PAL Langauge Compiler Program +++++";
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;

            // Starting Point for Main..
            Console.WriteLine("  \n     Press Enter To Start or Q To Exit");
            String rFile = Console.ReadLine();
            while (!rFile.Equals("q"))
            {
                // Main Entry Point for User to Enter The Path...
                Console.WriteLine("\n     Please Enter Path to Compile Your PAL File..... \n");
                args = new String[1] { Console.ReadLine() };
                foreach (String fileName in args)
                {
                    if (args.Length < 1)
                    {
                        Console.WriteLine("\n     Please Enter Path to Compile Your PAL File..... \n");
                        args = new String[1] { Console.ReadLine() };
                    }//end if

                    else if (args.Length > 1)
                        Console.WriteLine(" \n Extension Issue - File speficied Is Incorrect - Please Check Path, and Try Again... \n ");

                    if (args.Length == 1)
                    {
                        Console.Clear();
                        Console.WriteLine(" \n Loading Path, Please Wait while: {0} Is Loaded...", args[0], "...");
                        try
                        { 
                            infile = new StreamReader(args[0]);
                            PAL_Parser myParser = new PAL_Parser();
                            myParser.Parse(infile);
                            foreach (CompilerError err in myParser.Errors)
                            {
                                Console.WriteLine(err);
                            }//end foreach
                            Console.WriteLine(" \n Error List Has Found {0} Error In PAL Language.... ", myParser.Errors.Count);

                        }//end try
                        catch (FileNotFoundException e)
                        {
                            Console.WriteLine(" \n Incorrect Path Name Speficied, Please ReCheck Path Name: " + e.Message);
                        }//end catch
                        catch (FileLoadException f)
                        {
                            Console.WriteLine(" \n PAL File Will Not Load, Contact Your Administrator (System Error): " + f.Message);
                        }//end catch
                        catch (IOException i)
                        {
                            Console.WriteLine(" \n I/O System Error, Contact Your Administrator (System Error): " + i.Message);
                        }//end catch
                        
                        Console.WriteLine(" \n Press Enter If You Wish to Test Other PAL File Else Q Exit");
                    }//end else if
                }
                rFile = Console.ReadLine();
                if (!rFile.Equals("q"))
                {

                }

            }//end main entry point

        }//end class

    }//end namespace
}