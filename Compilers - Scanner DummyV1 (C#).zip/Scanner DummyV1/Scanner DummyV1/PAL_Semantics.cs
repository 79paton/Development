﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Ardkit - Reference
using AllanMilne.Ardkit;

namespace PAL_Language
{
    // Main Class inherting from Semantics (Ardkit)
    class PAL_Semantics : Semantics
    {

        // Constructor
        public PAL_Semantics(IParser p)
            : base(p)
        {

        }

        // Method - Check Type
        public void CheckType(IToken id)
        {
            int thisType = LanguageType.Undefined;
            if (id.Is(Token.IdentifierToken))
                thisType = Scope.CurrentScope.Get(id.TokenValue).Type;
            else if (id.Is(Token.IntegerToken))
                thisType = LanguageType.Integer;
            else if (id.Is(Token.RealToken))
                thisType = LanguageType.Real;
            if (currentType == LanguageType.Undefined)
                currentType = thisType;
            if (currentType != thisType)
            {
                    semanticError(new TypeConflictError(id, thisType, currentType));
            }
        } // End Method - Check Type

        // Method - Check if Token is Defined
        public void CheckId(IToken id)
        {

            // Token return - do nothing
            if (!id.Is(Token.IdentifierToken)) return;
            
            // Check token is in symbol table
            if (!Scope.CurrentScope.IsDefined(id.TokenValue))
            {
                semanticError(new NotDeclaredError(id));
            }
            else CheckType(id);          
                // is parser in recovery
                //if (!parser.IsRecovering)
        } // End Method - CheckId method.


        // Method - Declare Check on Tokens
        public void DeclareId(IToken id)
        {
            // Test Tokens to check if they are decalred
            if (!id.Is(Token.IdentifierToken)) return;

            Scope symbols = Scope.CurrentScope;
            if (symbols.IsDefined(id.TokenValue))
            {
                    semanticError(new AlreadyDeclaredError(id, symbols.Get(id.TokenValue)));
            } // end DeclareId method. 
            else
                symbols.Add(new VarSymbol(id, currentType));

        }
    }
}

  

