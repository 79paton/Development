<?php

	// Script used for the MembersLogout
	// Displays message Log Out Click Here To Finish
	// Click Here will be displayed as a link to return to Home.php
	// The user session id will be destroyed once Click Here is pressed
	// and will have to login to start session again from LoginMain.php
	// which is the standard non signed in page

	session_start();
	session_destroy();
	echo "Log Out. <a href='Home.php'> Click Here </a> To Finish.";
	


?>