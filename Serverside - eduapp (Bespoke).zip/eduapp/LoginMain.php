<html>
<head>

<!--- Sets the login form, that will use the login php file to check user --->


<!--- The link is the template for the websites css design ---->
<link href="Style1.css" rel="stylesheet" type="text/css">

<title> Login </title>
</head>
<body>

<?php

// Once User has selected login session will start with the user id

session_start();

// Variables

$username = $_POST['username'];
$password = $_POST['password'];

// Check to see if username and password is correct I.E. what is in the database

if ($username && $password)
{

// Connection to database
$connect = mysql_connect("lochnagar.abertay.ac.uk","sql0501124","t8ajHIr5") or die ("Can't connect!");
	
mysql_select_db("sql0501124") or die ("Couldn't find database");

//Query to database to pull the username from authUsers table
$query = mysql_query ("SELECT * FROM authUsers 
						WHERE username = '$username'");

// Query check to see if the user and password exists						
$numrows = mysql_num_rows($query);

if ($numrows !=0)
{
	while ($row = mysql_fetch_array($query))
	{
		// Beings the session
		session_start();
		$dbusername = $row['username'];
		$dbpassword = $row['password'];
	}
	
	// Check the session variables, and logs the user in. Also hides the password with md5 to hash it
	if ($username == $dbusername && md5($password) == $dbpassword)
	{
		// Directs them to their Members Home Page
		// Setting the login as their username
		header('Location: MemberPageHome.php');
		$_SESSION['username'] = $username;
		$_SESSION['password'] = $password;
	}	
	// If it doesn't match password row in database, for password, display message
	else	
		echo "Incorrect Password";		
//	If it doesn't match username row in database, for username, display message	
}
else 
	die("That User Doesn't Exist");
}
// Will display this message if the user hasn't entered both username and password into the fields
else
	die ("please enter username and password details");
		
?>
</body>
</html>