<?php

// This script will display all app data from the user table Appdata, once moderated by admin
// which will come from AdminAappData table

// Connection 
$username="sql0501124";
$password="t8ajHIr5";
$database="lochnagar.abertay.ac.uk";

	$con=mysql_connect("lochnagar.abertay.ac.uk","sql0501124","t8ajHIr5");
	@mysql_select_db($username) or die ("UNABLE");
	
		// Per Page will display only two rows from the AppData table per page
		// It will use COUNT id to pull each row from AppData
		// It will then make sure that only two are displayed, by using ceil, which rounds it down
		
		$per_page = 2;
		$pages_query = mysql_query("SELECT COUNT('id') FROM AppData");
		$pages = ceil(mysql_result($pages_query, 0) / $per_page);
		
		// Will display each page correctly and then display the query data, which is the AppData table
		// Select can be used to return the required rows, I.E. appname, apptype and price
		$page = (isset($_GET['page'])) ?  (int)$_GET['page'] : 1;
		// Sets first page to zero
		$start = ($page - 1) * $per_page;
		$query = mysql_query("SELECT appname, apptype, price  FROM AppData LIMIT $start, $per_page");
		
		mysql_close($con);

?>
<html>
<head>
	<title> App Details</title>
</head>
<body>
<p>

<?php
	
	// Displays a table around the data pulled from the database
	echo "<table border=1 cellspacing=2 cellpadding=0>
	<tr>
	<th> App Name </th>
	<th> Type </th>
	<th> Price  </th>
	<th> Image </th>
	</tr>";
		
		
// Return the process query above, from the database, and returns the rows below in the table
while($query_row = mysql_fetch_assoc($query)) 
{
		
	echo "<tr>";
		echo "<td>" . $query_row['appname'] . "</td>";
		echo "<td>" . $query_row['apptype'] . "</td>";
		echo "<td>" . $query_row['price'] . "</td>";
		echo "<td>" ?> <img src="<?php echo $query_row['image'];?>"width="100" height="100">
		
		
		<?php
		echo "</tr>";
		}
		echo "</table>";

// This will set the page numbers, as the app numbers grow
// It will check to see if pages are more than one, and then add one I.E. 1 2 3 and the numbers will use
// the a href link to naviagate through the apps
// It will remove or add one as the apps are added ot removed from database

if($pages >= 1) 
{

	for($i=1; $i<=$pages;$i++)
	{
		
		echo ($i == $page) ? ' <b><a href="?page='.$i.'">'.$i.'</a></b> ' : ' <a href="?page='.$i.'">'.$i.'</a> ';

	}
}

?>