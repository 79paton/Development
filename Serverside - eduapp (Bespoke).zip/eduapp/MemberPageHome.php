<html>
<head>

<!--- This the main member page login page --->

<!--- The link is the template for the websites css design ---->
<link href="Style1.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="container">

<div id="header">

<p class="headername">EduApp</p>

<div class="login">

<ul>
<div>
	<!-- Displays the user logged in the top bar -->
	<?php require_once ("MemberPage.php"); ?>
</div>
</ul>

</div>
</div>
</div>

<div id="horizontalnav">



<div class="navlinks">



<ul>
<li><a href="MemberPageHome.php">Home Page</a></li>
<li><a href="MemberAppListing.php">App Listing</a></li>
<li><a href="SubmitApp.php">Submit App</a></li>
<li><a href="TutorInfo.php">Tutor Info</a></li>
</ul>
</div>

</div>


<div id="leftnav">This is the leftnav
	
</div>

<div id="rightnav">This is the rightnav</div>

<div id="body"><br>

<!-- Displays some images in the main body -->
<div><?php require_once ("Images.php"); ?>


<div

class = "box">

Welcome to my Web page 

This site is my third year Server Side Development project, That will show students the benefits of using
educational applications as they study through out the year.

The site will offer many different style of apps to the you.

You can upload your own app to the site.

The site also offers you to write comments on apps that are on the site,
along with a rating system, that will show its popularity with other students.

Please feel to register.

My Details for contact is 0501124@abertay.ac.uk

Thank You for Visiting my Web Page!

</div>
</div>
</div>

<div id="footer">CE0932A: Server Side Development
<p> Neil Paton 0501124  </p>
<p class="smalltext">Neil Paton's Webpage</p>

</div>

</div>

</body>
</html>