<html>
<head>

<!--- Process the search entry in the search box on the AppListingMain.php or MemberAppListing.php --->

<!--- The link is the template for the websites css design ---->
<link href="Style1.css" rel="stylesheet" type="text/css">
</head>
<body>

<?php

//ini_set("display_errors", 1);
//error_reporting(E_ALL);

// Create connection

// Pulls both data and images from MySQL Database

include("dbconnect.php");
	
	if(!isset($_POST['search'])) {

		// Return if search doesn't exist
		header("AppListingMain.php");

}
		// Result rows from database, showing only 2 per page
		// Will pull the rows by id from AppData table
		// and round the results down, to a whole number, using ceil
		$per_page = 2;
		$pages_query = mysql_query("SELECT COUNT('id') FROM AppData");
		$pages = ceil(mysql_result($pages_query, 0) / $per_page);
		
		// Once search is checked, will return the pages, displaying only what has been searched for
		$page = (isset($_GET['page'])) ?  (int)$_GET['page'] : 1;
		// Sets first page to zero, as the database starts at zero and not one
		$start = ($page - 1) * $per_page;
		// Query to select the data require from AppData that matches the search input for apptype and appname, by
		// using the LIKE % operator to check for those characters
		$query = mysql_query (" SELECT appname, apptype, price FROM AppData WHERE appname LIKE '%".$_POST['search']."%' OR apptype LIKE '%".$_POST
		['search']."%' LIMIT $start, $per_page") ;
		
		// close database connection once query has finished
		mysql_close($con);

?>
<html>
<head>
	<title> Test of PHP connecting to a MYSQL database</title>
</head>
<body>
<p>

<?php
	
	// Table for data to set in, under their correct headings
	echo "<table border=1 cellspacing=2 cellpadding=0>
	<tr>
	<th> App Name </th>
	<th> Type </th>
	<th> Price  </th>
	<th> Image </th>
	</tr>";
		
// fetches the data queried from above and displayed them in the table	
while($query_row = mysql_fetch_assoc($query)) 
{
		
	echo "<tr>";
		echo "<td>" . $query_row['appname'] . "</td>";
		echo "<td>" . $query_row['apptype'] . "</td>";
		echo "<td>" . $query_row['price'] . "</td>";
		echo "<td>" ?> <img src="<?php echo $query_row['image'];?>"width="100" height="100">
		
		
		<?php
		echo "</tr>";
		}
		echo "</table>";


// Will add one pages for every two rows returned to the screen
// It will display the link to each page by numbers below the app results
// This method will ensure a page is added each time a page becomes full I.E. 2 per page displaying 
// the thrid on a new page.
if($pages >= 1) 
{

	for($i=1; $i<=$pages;$i++)
	{
	
		echo ($i == $page) ? ' <b><a href="?page='.$i.'">'.$i.'</a></b> ' : ' <a href="?page='.$i.'">'.$i.'</a> ';

	}
}

?>