<?php


echo "<h1> Register </h1>";

$submit = $_POST['submit'];

//form data variables
// The strip_tags() function strips a string from HTML, XML, and PHP tags
$fullname = strip_tags($_POST['fullname']);
$username = strtolower(strip_tags($_POST['username']));
$password = strip_tags($_POST['password']);
$confirmpassword = strip_tags($_POST['confirmpassword']);
$date = date("Y-m-d");

//md5 to encrypt passwords

if ($submit)
{
	//open database connection
	$connect = mysql_connect("lochnagar.abertay.ac.uk","sql0501124","t8ajHIr5") or die ("Can't connect!");
	//Select database
	mysql_select_db("sql0501124") or die ("Couldn't find database");
	// Runs the query to select user names from authUsers to check if user exists already.
	$namecheck = mysql_query("SELECT username FROM authUsers WHERE username='$username'");
	$count = mysql_num_rows($namecheck);
	
	// If it does match a row in the table display message
	if($count !=0)
	{
		die("UserName Already Taken!");
	}
	
	//check for existence
	if($fullname && $username && $password && $confirmpassword)
	{
		
		if ($password == $confirmpassword)
		{
			//check character length of username and fullname is higher than 25
			if (strlen($username)>25 || strlen($fullname) >25)
			{
				// Display error message if  username or Fullname is longer than 25
				echo "Length of username or fullname is too long! ";
				header("HomeRegister.php");
			}
			else
			{
			//check password length is between 6 and 25
				if(strlen($password)>25 || strlen($password)<6)
				{
					// else display error message
					echo "Password must be between 6 and 25 chars";
				}
				else
				{
					//register the user. 
					//encrypt password.
					$password = md5($password);
					$confirmpassword = md5($confirmpassword);
					
					
					// query to insert the fields if they meet validation, to the authUsers Table 
					$queryreg = mysql_query("
					INSERT INTO authUsers VALUES ('', '$fullname','$username','$password','$date')
					
					");
					// Display message if inputs are excepted and display message with link to return home to loginin 
					die ("You Have been Registered! <a href='Home.php'> Return to Login Page</a>");
				}
			}
		}
		// Checks to see if both password inputs macth
		else
			echo "Your Passwords Don't Match!";
	// Checks all fields are in putted, else display error message 
	}
	else
		echo "Please Fill In <b>All</b> Fields please";	
}
?>

<html>
<p>
<head>


<!--- Sets the login form, that will use the login php file to check user --->

<link href="Style1.css" rel="stylesheet" type="text/css">

<title> Input Details </title>
</head>
<body>

<form action = 'register.php' method='POST'>
	<table>
		<tr>
			<td>
			Your Full Name:
			</td>			
			<td>
			<input type ='text' name='fullname' value='<?php echo $fullname ?>'>
			</td>
		</tr>
		<tr>
			<td>
			Choose a Username:
			</td>		
			<td>
			<input type ='text' name='username' value='<?php echo $username ?>'>
			</td>
		</tr>
		<tr>
			<td>
			Choose a Password:
			</td>			
			<td>
			<input type ='password' name='password'>
			</td>
		</tr>
		<tr>
			<td>
			Confirm Password:
			</td>		
			<td>
			<input type ='password' name='confirmpassword'>
			</td>
		</tr>
	</table>
	<input type ='submit' name='submit' value='Register'>
</form>

</body>			
</html>