<?php

//ini_set("display_errors", 1);
//error_reporting(E_ALL);

// This page will process the submit button from the Appsubmit.php page
// it will pass the submitted data into the AdminAppData table, to be moderated 

//Create connection

$username="sql0501124";
$password="t8ajHIr5";
$database="lochnagar.abertay.ac.uk";

$con=mysql_connect("lochnagar.abertay.ac.uk","sql0501124","t8ajHIr5");
	@mysql_select_db($username) or die ("UNABLE");
	
	// This query will pull the data from the input fields to the AdminAppData table to be moderated 
		$sql1 = "INSERT INTO AdminAppData (appname, apptype, price) VALUES ('".$_POST['appname']."','".$_POST['apptype']."','".$_POST['price']."')";
		$rs=mysql_query($sql1) or die ("Unable to run query 1");
		header('Location: MemberPageHome.php');
	
?>
<html>
<head>
	<title> Test of PHP connecting to a MYSQL database</title>
</head>
<body>

</body>
<!-- This Message will be presented to user once the select the submit button -->
Your App has been Submitted, It Will Appear Once Admin has accepted Your App.

</html>