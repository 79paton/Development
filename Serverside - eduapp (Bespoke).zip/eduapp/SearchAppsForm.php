

<!--  Search Input box to search available apps on AppListingMain.php or MemberAppListing.php --->
<!--  It will display the results on the AppListingResults.php page --->

<p> Search <p>
<form name ="form1" method ="post" action="AppListingResults.php">
	<input name="search" type="text" size="15" maxlength="15" />
	<input type="submit" name="submit" value="Search" />
	
	
</form>