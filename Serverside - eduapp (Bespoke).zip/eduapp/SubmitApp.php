<html>
<head>

<!--- Will use the script MemberPage.php to show they are logged in at the top ---->
<!--- or it will ask them to sign in if they try to click on the link with out being logged in --->
<!--- If they are logged in, they will be displayed by the SubmitApp.php to enter app details --->

<link href="Style1.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="container">

<div id="header">

<p class="headername">EduApp</p>

<div class="login">

<ul>
<li><?php require_once ("MemberPage.php"); ?></li>
</ul>

</div>
</div>
</div>

<div id="horizontalnav">



<div class="navlinks">



<ul>
<li><a href="MemberPageHome.php">Home Page</a></li>
<li><a href="MemberAppListing.php">App Listing</a></li>
<li><a href="SubmitApp.php">Submit App</a></li>
<li><a href="TutorInfo.php">Tutor Info</a></li>
</ul>
</div>

</div>


<div id="leftnav">This is the leftnav
	
</div>

<div id="rightnav">This is the rightnav</div>

<div id="body"> <br>

<div

class = "box" >

<div> <?php require_once ("AppSubmit.php"); ?>

</div>
</div>

</div>

<div id="footer">CE0932A: Server Side Development
<p> Neil Paton 0501124  </p>
<p class="smalltext">Neil Paton's Webpage</p>

</div>

</div>

</body>
</html>