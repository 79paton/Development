<html>
<head>
<link href="Style1.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="container">

<div id="header">

<p class="headername">EduApp</p>

<div class="login">

<div> <?php require_once ("MemberPage.php"); ?>

</div>
</div>
</div>

<div id="horizontalnav">



<div class="navlinks">



<ul>
<li><a href="MemberPageHome.php">Home Page</a></li>
<li><a href="MemberAppListing.php">App Listing</a></li>
<li><a href="SubmitApp.php">Submit App</a></li>
<li><a href="TutorInfo.php">Tutor Info</a></li>
</ul>
</div>

</div>


<div id="leftnav">This is the leftnav
<!-- Search box in the left nav bar, to input a search result-->
<div><?php require_once ("SearchAppsForm.php"); ?>
</div>
	
</div>

<div id="rightnav">This is the rightnav</div>

<div id="body"><br>
<div

class = "box">
<!-- Displays the search box in the results page-->
<div><?php require_once ("SearchApps.php"); ?>

</div>
</div>

</div>

<div id="footer">CE0932A: Server Side Development
<p> Neil Paton 0501124  </p>
<p class="smalltext">Neil Paton's Webpage</p>

</div>

</div>

</body>
</html>