<html>
<head>

<!--- This page will be displayed once the user selects login, and present a login form --->

<!--- The link is the template for the websites css design ---->
<link href="Style1.css" rel="stylesheet" type="text/css">


</head>
<body>

<div id="container">

<div id="header">

<p class="headername">eduAPP</p>

<div class="login">


<ul>
<li><a href="HomeLogin.php">Login</a></li>
<li><a href="HomeRegister.php">Registration</a></li>
</ul>

</div>
</div>
</div>

<div id="horizontalnav">



<div class="navlinks">



<ul>
<li><a href="Home.php">Home Page</a></li>
<li><a href="AppListingMain.php">App Listing</a></li>
<li><a href="SubmitApp.php">Submit App</a></li>
<li><a href="TutorInfo.php">Tutor Info</a></li>
</ul>
</div>

</div>


<div id="leftnav">This is the leftnav
	
</div>

<div id="rightnav">This is the rightnav</div>

<div id="body">This is the body <br>
<div

class = "box">
<!-- Displays a form to login -->
<div><?php require_once ("FormLogin.php"); ?>
</div>
</div>
</div>

<div id="footer">This is the footer

<p>  Footer Text </p>
<p class="smalltext">Neil Patons CSS sheet</p>

</div>

</div>

</body>
</html>