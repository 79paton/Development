<?php

//ini_set("display_errors", 1);
//error_reporting(E_ALL);

// Set up the form to allow for the input text to the database
// and the selected tables

//Create connection


$username="sql0501124";
$password="t8ajHIr5";
$database="lochnagar.abertay.ac.uk";

$con=mysql_connect("lochnagar.abertay.ac.uk","sql0501124","t8ajHIr5");
	@mysql_select_db($username) or die ("UNABLE");
	
		$sql = "SELECT * FROM scart" ;
		$result=mysql_query($sql) or die ("Unable to run query 1");
	
		mysql_close($con);

?>
<html>
<head>
	<title> Test of PHP connecting to a MYSQL database</title>
</head>
<body>
<p>
<?php
	
	echo "<table border=1 cellspacing=2 cellpadding=0>
	<tr>
	<th> App Name </th>
	<th> Type </th>
	<th> Price  </th>
	<th> Image </th>
	</tr>";
	
	//Displays now in my table
	while ($record = mysql_fetch_array($result)) {
		
		echo "<tr>";
		echo "<td>" . $record['appname'] . "</td>";
		echo "<td>" . $record['apptype'] . "</td>";
		echo "<td>" . $record['price'] . "</td>";
		echo "<td>" ?> <img src="<?php echo $record['image'];?>"width="100" height="100">
		
		
		<?php
		echo "</tr>";
		}
		echo "</table>";
		
	
?>

</p>
</body>
</html>


