<html>
<head>

<!--- This will a page that will be in-between the members pages and back to the normal pages --->
<!--- It will display a message once it runs the Logout.php script --->

<!--- The link is the template for the websites css design ---->
<link href="Style1.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="container">

<div id="header">

<p class="headername">EduApp</p>

<div class="login">

<div>
	<?php require_once ("Logout.php"); ?>
</div>

</div>
</div>
</div>

<div id="horizontalnav">



<div class="navlinks">



<ul>
<li><a href="Home.php">Home Page</a></li>
<li><a href="AppListingMain.php">App Listing</a></li>
<li><a href="SubmitApp.php">Submit App</a></li>
<li><a href="TutorInformation.php">Tutor Info</a></li>
</ul>
</div>

</div>


<div id="leftnav">This is the leftnav
	
</div>

<div id="rightnav">This is the rightnav</div>

<div id="body"><br>


</div>

<div id="footer">CE0932A: Server Side Development
<p> Neil Paton 0501124  </p>
<p class="smalltext">Neil Paton's Webpage</p>

</div>

</div>

</body>
</html>