<?php

//ini_set("display_errors", 1);
//error_reporting(E_ALL);

// This php file shows the use of two functions to bring out data from
// two tables in MySQL database

// Create connection

function dbconnect()
{
$username="sql0501124";
$password="t8ajHIr5";
$database="lochnagar.abertay.ac.uk";

$con=mysql_connect("lochnagar.abertay.ac.uk","sql0501124","t8ajHIr5","sql0501124");
	@mysql_select_db($username) or die ("UNABLE");
	
}

function dbshow($str)
{

$result=mysql_query($str);
return $result;

}

dbconnect();

$sql = "SELECT Name, Image FROM Images";
$result=dbshow($sql);

mysql_close();

?>

<?php
	echo '<table style="width:300px" border="0" cellspacing="0" cellpadding="0">';
	
	while ($db_field = mysql_fetch_assoc($result)) 
	{
	echo '<tr>';
			echo'<td>';?> <img src="<?php echo $db_field['Image'];?>" width="100" height="100">
				
			<?php
			echo '</td>';
			
			/*echo '<td>'; echo $db_field['Name']; echo '</td>';*/
		 echo'</tr>';
		 }
		 echo '</table>';
?>