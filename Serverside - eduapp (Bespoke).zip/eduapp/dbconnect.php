<?php

// Script to be used by any other page
// they will only need to put in require_once("dbconnect");

$username="sql0501124";
$password="t8ajHIr5";
$database="lochnagar.abertay.ac.uk";

$connect = mysql_connect("lochnagar.abertay.ac.uk","sql0501124","t8ajHIr5") or die ("Can't connect!");
	
mysql_select_db("sql0501124") or die ("Couldn't find database");

?>