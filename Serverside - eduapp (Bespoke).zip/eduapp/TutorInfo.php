<html>
<head>

<!---  Page Layout for Tutor Information  --->

<link href="Style1.css" rel="stylesheet" type="text/css">


</head>
<body>

<div id="container">

<div id="header">

<p class="headername">EduApp</p>

<div class="login">

<ul>
<li><a href="HomeLogin.php">Login</a></li>
<li><a href="HomeRegister.php">Registration</a></li>
</ul>

</div>
</div>
</div>

<div id="horizontalnav">



<div class="navlinks">



<ul>
<li><a href="Home.php">Home Page</a></li>
<li><a href="AppListingMain.php">App Listing</a></li>
<li><a href="SubmitApp.php">Submit App</a></li>
<li><a href="TutorInfo.php">Tutor Info</a></li>
</ul>
</div>

</div>


<div id="leftnav">This is the leftnav
	
</div>

<div id="rightnav">This is the rightnav</div>

<div id="body"><br>


<div

class = "box">

<li><a href="AdminLogin.php">Tutor Info</a> User Name - Admin Password - Admin </li> <br>

AdminAppData Table - id appname apptype price <br>

AppData Table - id appname apptype price confirm adminid <br>

AdminLogin - username password <br>

authUsers - customerid name username password <br>

Images - Name Image <br>

Issues:

Ended with AdminAppListing - Errors with CSS displaying results
No Comment system or rating system for user
No un-moderated system to check reviews



</div>


</div>

<div id="footer">CE0932A: Server Side Development
<p> Neil Paton 0501124  </p>
<p class="smalltext">Neil Paton's Webpage</p>

</div>

</div>

</body>
</html>