<?php

	session_start();
	
	if ($_SESSION['username'])
	
		echo "Welcome, " .$_SESSION['username']."! <br> <a href = 'logout.php'> LogOut </a>";	
	else
		die("You Must Be Logged In!");
		
?>