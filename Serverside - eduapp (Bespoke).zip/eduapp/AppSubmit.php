

<!--- Simple form that will be used to input app details  --->
<!--- Once user selects submit, will be passed to AppUpdateDataBase.php page  --->

<title> Submit Your App </title>


</head>
<body>

<form method="post" action="AppUpdateDatabase.php">

<label> App Name -
<input type="text" name="appname" id="appname" />
</label>


<p>
<label> App Type - 
<Select NAME="apptype">
 <Option VALUE="Developer">Developer</option>
 <Option VALUE="Educational">Educational</option>
</Select>
</label>
</p>


<p>
<label> Price -
	<input type="text" name="price" id="price" />
</label>
</p>

<p>
<input type="submit" name="button" id="button" value="submit" />
</p>
</form>



</body>

</html>
