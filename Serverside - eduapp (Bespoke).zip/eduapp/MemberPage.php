<?php

	// This will start the users session based on their username from database
	// session_start(); will start the session
	// The session varialbe will set the username in the top right conner with link to Log Out
	// This script will be used on all member pages, with the username and logout link

	session_start();
	
	if ($_SESSION['username'])
	
		echo "Welcome, " .$_SESSION['username']."! <a href = 'MembersLogout.php'> Log Out </a>";	
		
		// This message will be displayed for any pages that require a login, such as submit app page.
	else
		die("<a href = 'Home.php'>Return Home</a> Please Sign In!");
		
		
		
?>