<html>
<head>


<!--- Sets the login form, that will use the LoginMain.php file to allow  --->
<!--- user to login or a link to register if they have not done so  --->

<!--- The link is the template for the websites css design ---->
<link href="Style1.css" rel="stylesheet" type="text/css">

<title> Input Details </title>
</head>
<body>

<form method="POST" action="LoginMain.php">

<label>UserName
<input type="text" name="username" id="username" />
</label>
<p>

<label>Password
	<input type="password" name="password" id="password" />
</label>
</p>
<p>
<p>

<input type="submit" name="login" id="button" value="login" />
</p>
</form>

<a href = 'HomeRegister.php'> Register? </a>

</body>
</html>