<html>
<head>

<!--- This is the app listing for members logged in --->

<!--- The link is the template for the websites css design ---->
<link href="Style1.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="container">

<div id="header">

<p class="headername">EduApp</p>

<div class="login">
<!-- Displays a log in message at the top of the bar -->
<div> <?php require_once ("MemberPage.php"); ?>

</div>
</div>
</div>

<div id="horizontalnav">



<div class="navlinks">



<ul>
<li><a href="MemberPageHome.php">Home Page</a></li>
<li><a href="MemberAppListing.php">App Listing</a></li>
<li><a href="SubmitApp.php">Submit App</a></li>
<li><a href="TutorInfo.php">Tutor Info</a></li>
</ul>
</div>

</div>


<div id="leftnav">This is the leftnav
<div><?php require_once ("MemberAppSearchForm.php"); ?>
</div>	
</div>

<div id="rightnav">This is the rightnav</div>

<div id="body"><br>

<div

class = "box">

<!-- Will use the script to display results on the main body of page -->
<div> <?php require_once ("Pageinton2.php"); ?>


</div>
</div>
</div>

<div id="footer">CE0932A: Server Side Development
<p> Neil Paton 0501124  </p>
<p class="smalltext">Neil Paton's Webpage</p>

</div>

</div>

</body>
</html>