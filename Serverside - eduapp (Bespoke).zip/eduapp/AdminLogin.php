<html>
<head>
<link href="Style1.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="container">

<div id="header">

<p class="headername">EduApp</p>

<div class="login">

<ul>
<li><a href="HomeLogin.php">Login</a></li>
<li><a href="HomeRegister.php">Registration</a></li>
</ul>

</div>
</div>
</div>

<div id="horizontalnav">



<div class="navlinks">



<ul>
<li><a href="Home.php">Home Page</a></li>
<li><a href="AppListingMain.php">App Listing</a></li>
<li><a href="SubmitApp.php">Submit App</a></li>
<li><a href="TutorInfo.php">Tutor Info</a></li>
</ul>
</div>

</div>


<div id="leftnav">This is the leftnav
	
</div>

<div id="rightnav">This is the rightnav</div>

<div id="body"><br>

<div
class = "box">
<!-- Will display a log in for the Admin, which will use the AdminLogin table -->
<div><?php require_once ("(1)LoginForm.cfm"); ?>

</div>
</div>
</div>


</div>

<div id="footer">CE0932A: Server Side Development
<p> Neil Paton 0501124  </p>
<p class="smalltext">Neil Paton's Webpage</p>

</div>

</div>

</body>
</html>